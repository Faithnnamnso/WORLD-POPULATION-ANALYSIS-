USE Faith
GO

select * from world_population
--list all countries and their capitals
select country_Territory, Capital
from world_population
--The total area of each continent and how many countries does it contain
select Continent, SUM(Area_km) as Total_Area,
count(Country_Territory) as Number_of_countries
from World_population
group by Continent
--count all countries in the world_population data set
select count ( Country_territory) as Total_country
from world_population
--How many countries are there in each continent
select continent, count(Country_Territory) as Nummber_of_countries
from world_population
group by Continent
-- countries whose population was greater than 100 million in the year 2022
select country_territory, _2022_population
from world_population 
where _2022_population > 100000000
--The 10 countries with the highest population growth rate in the world
select Top 10 Country_Territory, Growth_Rate
from world_population 
order by Growth_rate desc
--population growth from the year 2000 and the year 2022
select Country_Territory, (_2022_population - _2000_population) as Population_Growth 
from world_population 
order by population_Growth desc
-- the largest countries by Area 
select Top 10 country_Territory, Area_km from world_population 
order by Area_km desc
--The capital with the highest density
select Top 1 capital from world_population 
order by Density_per_km desc
--The countries in the continent Asia
select country_Territory from world_population 
where continent = 'Asia'
--The five highest countries by world population percentage 
select Top 5 Country_Territory,world_population_percentage 
from world_population
order by world_population_percentage desc
--The total population for each country in 2015
select Country_Territory, _2015_population as Population_2015
from world_population

